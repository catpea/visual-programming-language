import Observable from "./Observable.js";

export default class Item extends Observable {

}
