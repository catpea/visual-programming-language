export default class Focusable {}
