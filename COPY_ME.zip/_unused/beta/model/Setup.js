import Item from "./Item.js";

export default class Setup extends Item {

  constructor(properties, application){
    super();
    this.inherit(properties);
  }

}
