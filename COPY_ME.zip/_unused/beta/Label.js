import { svg, html, mouse, click, update, text, clip, front } from "domek";

import Control from "./Control.js";

export default class Label extends Control {



}
