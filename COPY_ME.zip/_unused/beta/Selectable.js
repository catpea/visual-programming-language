export default class Selectable {}
