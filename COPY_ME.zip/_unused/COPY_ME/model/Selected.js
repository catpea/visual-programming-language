import Item from "./Item.js";

export default class Selected extends Item {

  constructor(properties, application){
    super();
    this.inherit(properties);
  }

}
