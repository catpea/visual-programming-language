import Container from "./Container.js";
import { VerticalLayout } from "./Layout.js";
import World from "./World.js";
import Button from "./Button.js";
import Workspace from "./Workspace.js";
import Zoomable from "./Zoomable.js";



import { v4 as uuid } from "uuid";

import { svg, html, mouse, click, update, text, clip, front } from "domek";

// import CodeEditor from '#plug-ins/code-editor/CodeEditor.js';
import NodeEditor from '#plug-ins/node-editor/NodeEditor.js';
// import DesignEditor from '#plug-ins/design-editor/DesignEditor.js';


// import Canvas from './application/view/Canvas.js';


import Application from "./Application.js";
import Canvas from "./Canvas.js";
import { ManualLayout } from "./Layout.js";



import kebabCase from "lodash/kebabCase.js";

export default class Universe extends Container {



  constructor(title, {svg, scene}, ...argv) {
    super(kebabCase(title), ...argv);

    this.title = title;
		this.layout = new ManualLayout(); // NOTE: a layout applies to children only, this will not set xywh of the root component
    this.svg = document.querySelector(svg);
    this.scene = this.svg.querySelector(scene);
    this.scene.appendChild( this.g ); // install it self

    this.view = {observe: ()=>{}};

    // PART ONE
		this.application = new Application();
		this.application.start();

    // this.application.Archetypes.create({id:'CodeEditor', class:CodeEditor});
		this.application.Archetypes.create({id:NodeEditor.type, class:NodeEditor});
		// this.application.Archetypes.create({id:'DesignEditor', class:DesignEditor});

    this.start();

	}



  createElements() {

    super.createElements();
		this.el.ClipPath = svg.clipPath({ id:uuid(), class: `clip-path`});
		this.el.Scene = svg.g();
		this.innerScene = svg.g();
		this.el.Scene.appendChild(this.innerScene);
		this. clipRect = svg.rect({ class: `clip-rect`, stroke:'black', fill:'black', ...this.b});
		this.el.ClipPath.appendChild(this.clipRect);
		update(this.el.Scene, { 'clip-path': `url(#${this.el.ClipPath.id})` })
		this.application.Views.create({ id:'id-of-port', scene: this.innerScene }, {entity:Canvas});


	}





  start() {

    super.start();


    this.application.Connectables.observe('created', v=>this.displayConnectable(v), {autorun: false})
    this.application.Connectables.observe('removed', v=>this.disposeConnectable(v), {autorun: false})
    this.application.Connections.observe('created', v=>this.displayConnection(v), {autorun: false})
    this.application.Connections.observe('removed', v=>this.disposeConnection(v), {autorun: false})

    const trays = [

    ];

    for (const tray of trays) {

      const world1 = new World("Visual Basic #1", {hMin:500, w: 800, radius:4, gap:1});
      this.children.add( world1 ); // adds the .g to the svg and .start()s the component
      world1.loadTools('visual-basic');
      world1.loadNodes('templates/hello-world.json');
      world1.x = 10;
      world1.y = 10;
      world1.w = 800;

    }

    this.application.Connectables.create(World, );



    //
    // const window1 = new Window('Tray!', {hMin:500, w: 800, radius:4, gap:1});
    // window1.data = {observe: ()=>{}}; // data will now be available under .root.data
    // window1.view = {observe: ()=>{}};
    // this.children.add( window1 ); // adds the .g to the svg and .start()s the component
    // window1.x = 10;
    // window1.y = 10;
    // window1.w = 800;
    //
    // const window2 = new Window('Tray!', {hMin:500, w: 800, radius:4, gap:1});
    // window2.data = {observe: ()=>{}}; // data will now be available under .root.data
    // window2.view = {observe: ()=>{}};
    // this.children.add( window2 ); // adds the .g to the svg and .start()s the component
    // window2.x = 100;
    // window2.y = 550;
    // window2.w = 850;




    // const windowCaption = new Button(this.title, {h:15});
    // const workspaceTest = new Workspace("./templates/hello-world.json", "test", {h:100, color: 'red'});
    // workspaceTest.view = this.view;
    // this.children.add(windowCaption, workspaceTest);
    // this.use(new Zoomable());


    /*
    Root window maximization code
    */
    const initializePosition = ()=>{
      const {width,height} = this.svg.getBoundingClientRect();
      Object.assign(this, {
        w: width-(this.design.padding+this.design.border*2),
        h: height-(this.design.padding+this.design.border*2),
      });
      this.design.hMin = height;
      this.design.color = 'red';
    }
    window.addEventListener("resize", initializePosition);
    this.cleanup(()=>window.removeEventListener("resize", initializePosition));
    initializePosition(); // boot
	}





  displayConnectable({ item }) {
    const types = [ World ]; //NOTE: multiple component classes are supported, and new ones should be added
    const Component = types.find(o=>o.name==item.type);
    if(!Component) return;
    const connectable = new Component();
    this.renderers.set(item.id, connectable);
    connectable.start({ item, view: this });
  }
  disposeConnectable({ item }) {
    this.renderers.get(item.id).stop();
  }

  displayConnection({ item }) {
    // const types = [Connection]; //NOTE: multiple component classes are supported, and new ones should be added
    const types = []; //NOTE: multiple component classes are supported, and new ones should be added
    const Component = types.find(o=>o.name==item.type);
    if(!Component) return;
    const connectable = new Component();
    this.renderers.set(item.id, connectable);
    connectable.start({ item, view: this });
  }
  disposeConnection({ item }) {
    this.renderers.get(item.id).stop();
  }

}
