// Boot Script - this is a boot sctipt that gets all the non-symmetrical oddities out of the way
import bootstrapCss from 'bootstrap/dist/css/bootstrap.min.css';
import bootstrapJs from 'bootstrap/dist/js/bootstrap.bundle.min.js';

import Universe from './Universe.js';
import Application from './Application.js';

import Nostromo from '../themes/nostromo/index.js';
import Obsidian from '../themes/obsidian/index.js';

// used in theme creation - TODO: theme system may need to be separate
const application = new Application();
application.start();

application.Themes.create({}, {entity:Nostromo});
application.Themes.create({}, {entity:Obsidian});
application.Themes.select('nostromo');

new Universe('Universe Window', {svg:'#editor-svg', scene:'#editor-scene'});
