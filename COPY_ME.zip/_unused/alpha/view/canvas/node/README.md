SVG Layout Manager

## Margins

Margins are not allowed because they violate code symmetry.

The .height property becomes invalid, as the user wants .height without margin, but the program with margin
this is ugly, hacky, and stupid, margins are a silly that should have never been implemented anywhere idea.
